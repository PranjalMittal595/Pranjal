<?php
	namespace Objectify\Objects;
	
	class TenantStringTableEntry
	{
	}
?>
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Concertroid.Renderer
{
    public class DebugScreen : Caltron.Screen
    {
        protected override void OnRender(Caltron.RenderEventArgs e)
        {
            base.OnRender(e);
        }
    }
}

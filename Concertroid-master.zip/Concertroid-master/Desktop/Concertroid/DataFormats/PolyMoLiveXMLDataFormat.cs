﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using UniversalEditor.DataFormats.Markup.XML;

namespace Concertroid.DataFormats
{
    public class PolyMoLiveXMLDataFormat : XMLDataFormat
    {
    }
}

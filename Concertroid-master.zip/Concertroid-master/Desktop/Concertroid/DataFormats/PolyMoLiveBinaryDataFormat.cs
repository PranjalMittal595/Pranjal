﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using UniversalEditor;

namespace Concertroid.DataFormats
{
    public class PolyMoLiveBinaryDataFormat : DataFormat
    {
        protected override void LoadInternal(ref ObjectModel objectModel)
        {
            throw new NotImplementedException();
        }
        protected override void SaveInternal(ObjectModel objectModel)
        {
            throw new NotImplementedException();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Caltron.Binders.WindowsFormsBinder
{
	public partial class CanvasHost : UserControl
	{
		public CanvasHost()
		{
			InitializeComponent();
		}
	}
}

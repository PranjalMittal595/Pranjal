Concertroid
===========

One central repository for everything related to the Concertroid virtual concert production system.
